space
=====

A simple game in which you control a little planet which need to grow in order to survive.
